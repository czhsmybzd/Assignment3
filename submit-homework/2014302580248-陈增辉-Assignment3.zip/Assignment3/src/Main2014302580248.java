import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main2014302580248 implements Runnable{
	static String linkhref;
	public static void main(String[] args) throws IOException, InterruptedException{
		Main2014302580248 h1 = new Main2014302580248();
		String html = "http://www.wpi.edu/academics/cs/research-interests.html";
		Document doc = Jsoup.connect(html).get();
		Element mytable = doc.getElementsByTag("body").first(); 
		//Elements a = mytable.getElementsByTag("ul");
		//for(Element d:a){
		ExecutorService threadExecutors = Executors.newCachedThreadPool();
		Elements b = mytable.getElementsByClass("half");
		//���ȵ��߳���ȡ
		Date t1 = new Date();
        long start1 = t1.getTime();
        for(Element e:b){
			Elements a = e.getElementsByTag("a");
			for(Element a1:a)
			{String linkHref = a1.attr("href").trim();
			System.out.println(linkHref);
			output(linkHref);
		}
		}
        Date e1 = new Date();
		long end1 = e1.getTime();
		//Ȼ����߳���ȡ
		Date t2 = new Date();
        long start2 = t2.getTime();
        //threadExecutors.execute(h1);
        //threadExecutors.execute(h1);
        //threadExecutors.execute(h1);
        //threadA.start();
        //threadB.start();
        //threadC.start();
        //boolean tasksEnded = threadExecutors.awaitTermination(1, TimeUnit.MINUTES);
        //if(tasksEnded)
        //{
        for(Element e:b){
			Elements a = e.getElementsByTag("a");
			for(Element a1:a)
			{String linkHref = a1.attr("href").trim();
			System.out.println(linkHref);
			threadExecutors.execute(h1);
		}
        Date e2 = new Date();
		long end2 = e2.getTime();
		System.out.printf("���߳���ȡ����ʱ��:%s\n",end1 - start1);
		boolean threadsEnded = threadExecutors.awaitTermination(1, TimeUnit.MINUTES);
		if(threadsEnded){
		System.out.printf("���߳���ȡ����ʱ��:%s\n",end2 - start2);
		}
        //}
	}}
	
	
	
	public static void geturl() throws IOException{
		
		String html = "http://www.wpi.edu/academics/cs/research-interests.html";
		Document doc = Jsoup.connect(html).get();
		Element mytable = doc.getElementsByTag("body").first(); 
		//Elements a = mytable.getElementsByTag("ul");
		//for(Element d:a){
		Elements b = mytable.getElementsByClass("half");
		for(Element e:b){
			Elements a = e.getElementsByTag("a");
			for(Element a1:a)
			{
				linkhref = a1.attr("href").trim();
				System.out.println(linkhref);
				output(linkhref);
		}
		}
	}
	
	public static void output(String linkHref) throws IOException{
		Document doc = Jsoup.connect(linkHref).get();
        File file = new File("newteacher.txt");
		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file,true));
		Element mytable = doc.getElementsByTag("body").first();
		Elements h = mytable.getElementsByTag("h2");
		Elements l = mytable.getElementsByClass("col");
		if(!h.isEmpty())
			for(Element a:h)
			{
				String c = a.text().trim();
				bufferedWriter.write(c + "\r\n");
				System.out.println(c);
				break;
			}
		//Elements p = mytable.getElementsByTag("P");
		
		//Elements teacher = mytable.select("p:matches([a-zA-Z][\\w\\.-]*[a-zA-Z0-9]@[a-zA-Z0-9][\\w\\.-]*[a-zA-Z0-9]\\.[a-zA-Z]$*)");
					
		//String[] head = teacher.text().split(" ");
		if(!l.isEmpty())
			for(Element a:l)
			{
				String c = a.text().trim();
				bufferedWriter.write(c + "\r\n");
				System.out.println(c);
				break;
			}
			
		bufferedWriter.close();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try {
			output(linkhref);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}


